# easy_blockchain

you can use blockchain easily.
please use for prototype

簡単にブロックチェーンを使うためのライブラリ．
IoTに組み込んだりなど，簡易的なプロトタイプ作成に使ってください．

# 今後やること

ブロックチェーンのデータ形式をjsonにするなど柔軟化する．
